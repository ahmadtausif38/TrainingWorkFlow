package com.hcl.elch.freshersuperchargers.trainingworkflow.service;

import java.util.List;

import com.hcl.elch.freshersuperchargers.trainingworkflow.entity.Task;

public interface SchedulerService {
	public void fetchTask() throws Exception;
}
