package com.hcl.elch.freshersuperchargers.trainingworkflow.exceptions;

public class KafkaReceiverException extends Exception
{
	public KafkaReceiverException(String str, Exception e) {	
		super(str);
		e.printStackTrace();
	}  

}
