package com.hcl.elch.freshersuperchargers.trainingworkflow.exceptions;

public class CamundaException extends Exception {
	
	public CamundaException(String s,Exception e)
	{
		super(s);
		e.printStackTrace();
		System.out.println(s);
	}

}
